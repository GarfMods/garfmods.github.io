Simply put the data folder and the updt.dll file in %LocalAppData%\THUG Pro
Replace the files.
And that's it! Enjoy your animation mod.