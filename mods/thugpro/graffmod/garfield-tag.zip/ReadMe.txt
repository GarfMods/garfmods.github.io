Simply put the two folders (data and Save) in %LocalAppData%\THUG Pro
Then in THUG Pro, load the skater named Custom Tag Mod
And that's it! Enjoy your custom tag.